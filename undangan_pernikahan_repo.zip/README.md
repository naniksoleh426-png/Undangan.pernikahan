# Undangan Pernikahan Sundus & Rofiud

Ini adalah undangan pernikahan digital sederhana untuk **Sundus Istiqomah & M. Rofiud Darojat**.

## Cara akses
Setelah repository ini diaktifkan dengan **GitHub Pages**, undangan bisa dibuka melalui link:

```
https://username.github.io/undangan-pernikahan/
```

(ganti `username` dengan nama akun GitHub Anda).

## Struktur
- `index.html` → file utama undangan pernikahan

## Tema
Menggunakan nuansa hijau botol, hijau muda, dan hijau segar.

---
Dibuat dengan ❤️ semoga bermanfaat.
